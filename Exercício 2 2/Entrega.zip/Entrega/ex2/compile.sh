gcc -Wall -o cliente cliente.c
gcc -Wall -o servidor servidor.c